Admin credentials:

username:admin
password:admin